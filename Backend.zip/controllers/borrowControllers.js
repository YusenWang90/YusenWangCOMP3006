var dbConfig = require('../utils/dbconfig');


findBorrowUser = async (req, res) => {
  let { user_id } = req.body;

  let result = await dbConfig.sqlConnect(dbConfig.BorrowList, { user_id, back_date: null }).populate('book_id');

  if (result.length) {
    res.send({
      'code': 200,
      'msg': 'Get Success',
      'data': result
    })
  } else {
    res.send({
      'code': 400,
      'msg': 'Failed to get0'
    })
  }
}

getBorrowList = async (req, res) => {
  let result = await dbConfig.sqlConnect(dbConfig.BorrowList, {}).populate('book_id').populate('user_id');

  if (result) {
    res.send({
      'code': 200,
      'msg': 'Get Success',
      'data': result
    })
  } else {
    res.send({
      'code': 400,
      'msg': 'Failed to get',
    })
  }
}


addBorrow = async (req, res) => {
  let { book_id, user_id } = req.body;

  let result = await dbConfig.insert(dbConfig.BorrowList, { book_id, user_id, borrow_date: Date.now() });

  if (result) {
    res.send({
      'code': 200,
      'msg': 'Insertion successful'
    })
  } else {
    res.send({
      'code': 400,
      'msg': 'insertion failure'
    })
  }
}


addBookStatus = async (req, res) => {
  let { user_id, book_id } = req.body;

  let result = await dbConfig.update(dbConfig.BorrowList, { user_id, book_id, back_date: null }, { back_date: Date.now() });
console.log(result.modifiedCount);
  if (result.modifiedCount == 1) {
    res.send({
      'code': 200,
      'msg': 'Successful return of books'
    })
  } else {
    res.send({
      'code': 400,
      'msg': 'Failure to return books'
    })
  }
}

module.exports = {
  getBorrowList,
  findBorrowUser,
  addBookStatus,
  addBorrow
}