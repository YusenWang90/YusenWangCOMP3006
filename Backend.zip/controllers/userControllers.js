const dbConfig = require('../utils/dbconfig');
const User = dbConfig.User;

let isExist = async (name) => {
  let result = await dbConfig.sqlConnect(User, {name: name});
  console.log(result,"----");
  if (!!result&&result.length) {
    return result[0];
  } else {
    return false;
  }
}

let isExistId = async (id) => {
  let result = await dbConfig.sqlConnect(User, {_id: id});
  if (result.length) {
    return result[0];
  } else {
    return false;
  }
}

login = async (req, res) => {
  let { name, pwd } = req.body;
  let result = await isExist(name);
  if (result) {
    if (result.pwd == pwd) {
      res.send({ 'code': 200, 'msg': 'Login Successful', 'data': result })
    } else {
      res.send({ 'code': 400, 'msg': 'incorrect password' })
    }
  } else {
    res.send({ 'code': 400, 'msg': 'The user does not exist' })
  }
}

register = async (req, res) => {
  let { name, pwd, className, admin } = req.body;
  let result = await isExist(name);
  if (result) {
    res.send({ 'code': 400, 'msg': 'Registration failed, user already exists' })
  } else {
    if (name && pwd && className) {
      let user = { pwd, name, className, admin, last_login_time: new Date() };
      let result = await dbConfig.insert(User, user);
      if (result) {
        res.send({ 'code': 200, 'msg': 'Successful registration' })
      } else {
        res.send({ 'code': 400, 'msg': 'Registration Failure!' })
      }
    } else {
      res.send({ 'code': 400, 'msg': 'No valid information entered！' })
    }
  }
}

editUserpass = async (req, res) => {
  let { id, pwd, newpwd } = req.body;
  let result = await isExistId(id);
  if (result) {
    if (result.pwd == pwd) {
      let data = await dbConfig.update(User, {_id: id}, {pwd: newpwd});
      console.log(data,'===');
      if (data.modifiedCount == 1) {
        res.send({ 'code': 200, 'msg': 'Modified successfully' })
      } else {
        res.send({ 'code': 400, 'msg': 'Modification Failure' })
      }
    } else {
      res.send({ 'code': 400, 'msg': 'incorrect password' })
    }
  } else {
    res.send({ 'code': 400, 'msg': 'The username does not exist' })
  }
}


editUserinfo = async (req, res) => {
  let { id, name, className, admin } = req.body;
  let data = await dbConfig.update(User, {_id: id}, {name: name, className: className, admin: admin});
  console.log(data,']]]');
  if (data.modifiedCount == 1) {
    res.send({ 'code': 200, 'msg': 'Modified successfully' })
  } else {
    res.send({ 'code': 400, 'msg': 'Modification Failure' })
  }
}

getUserInfo = async (req, res) => {
  let { name } = req.body;
  let result = await isExist(name);
  if (result) {
    res.send({ 'code': 200, 'msg': 'Get Success', 'data': result })
  } else {
    res.send({ 'code': 400, 'msg': 'Failed to get' })
  }
}


getUserAll = async (req, res) => {
  let result = await dbConfig.sqlConnect(User, {});
  res.send({ 'code': 200, 'msg': 'Get Success', 'data': result })
}


editUserStatus = async (req, res) => {
  let { id, status } = req.body;
  let data = await dbConfig.update(User, {_id: id}, {status: status});
  console.log(data,'---');
  if (data.modifiedCount == 1) {
    res.send({ 'code': 200, 'msg': 'Modified successfully' })
  } else {
    res.send({ 'code': 400, 'msg': 'Modification Failure' })
  }
}


findUsername = async (req, res) => {
  let { name } = req.body;
  let result = await dbConfig.sqlConnect(User, {name: new RegExp(name)});
  if (result.length) {
    res.send({ 'code': 200, 'msg': 'Get Success', 'data': result })
  } else {
    res.send({ 'code': 400, 'msg': 'The user does not exist' })
  }
}


deleteUser = async (req, res) => {
  let { id } = req.body;
  let data = await dbConfig.delete(User, {_id: id});
  if (data.deletedCount == 1) {
    res.send({ 'code': 200, 'msg': 'Deleted successfully' })
  } else {
    res.send({ 'code': 400, 'msg': 'Failed to delete' })
  }
}





module.exports = {
  login,
  register,
  editUserpass,
  editUserinfo,
  editUserStatus,
  getUserInfo,
  getUserAll,
  findUsername,
  deleteUser,
  
}
