var dbConfig = require('../utils/dbConfig');
var mongoose = require('mongoose');


getBookAll = async (req, res) => {
  let {
    pagenum, 
    pagesize 
  } = req.body;

  pagenum = pagenum ? pagenum : 1;
  pagesize = pagesize ? Number(pagesize) : 5;
  let start = (pagenum - 1) * pagesize;

  let result = await dbConfig.BookInfo.find().skip(start).limit(pagesize);
  let total = await dbConfig.BookInfo.countDocuments();

  if (result.length) {
    res.send({
      'code': 200,
      'msg': 'Get Book List Success',
      'data': {
        'result': result,
        'total': total,
        'pagenum': pagenum,
        'pagesize': pagesize
      }
    })
  } else {
    res.send({
      'code': 400,
      'msg': 'The list of books is empty or the table does not exist',
    })
  }
}


findBook = async (req, res) => {
  let {
    bookname, 
    pagenum, 
    pagesize 
  } = req.body;

  pagenum = pagenum ? pagenum : 1;
  pagesize = pagesize ? Number(pagesize) : 5;
  let start = (pagenum - 1) * pagesize;

  let result = await dbConfig.BookInfo.find({ name: new RegExp(bookname, 'i') }).skip(start).limit(pagesize);
  let total = await dbConfig.BookInfo.countDocuments({ name: new RegExp(bookname, 'i') });

  if (result.length) {
    res.send({
      'code': 200,
      'msg': 'Get Success',
      'data': {
        'result': result,
        'total': total,
        'pagenum': pagenum,
        'pagesize': pagesize
      }
    })
  } else {
    res.send({
      'code': 400,
      'msg': 'Failed to get'
    })
  }
}


findBookAuthor = async (req, res) => {
  let { author } = req.body;

  let result = await dbConfig.BookInfo.find({ author: new RegExp(author, 'i') });

  if (result) {
    res.send({
      'code': 200,
      'msg': 'Get Success',
      'data': result
    })
  } else {
    res.send({
      'code': 400,
      'msg': 'Failed to get'
    })
  }
}


findBookPrice = async (req, res) => {
  let { price } = req.body;

  let result = await dbConfig.BookInfo.find({ price: { $lte: price } });

  if (result) {
    res.send({
      'code': 200,
      'msg': 'Get Success',
      'data': result
    })
  } else {
    res.send({
      'code': 400,
      'msg': 'Failed to get'
    })
  }
}


findBookIsbn = async (req, res) => {
  let { isbn } = req.body;

  let result = await dbConfig.BookInfo.find({ ISBN: isbn });

  if (result.length) {
    res.send({
      'code': 200,
      'msg': 'Get Success',
      'data': result
    })
  } else {
    res.send({
      'code': 400,
      'msg': 'non-existent'
    })
  }
}


findBookId = async (req, res) => {
  let { id } = req.body;

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.send({
      'code': 400,
      'msg': 'The supplied id is not a valid ObjectId'
    });
  }

  let result = await dbConfig.BookInfo.findById(id);

  if (result) {
    res.send({
      'code': 200,
      'msg': 'Get Success',
      'data': result
    })
  } else {
    res.send({
      'code': 400,
      'msg': 'non-existent'
    })
  }
}
// findBookId = async (req, res) => {
//   let { id } = req.body;

//   let result = await dbConfig.BookInfo.findById(id);

//   if (result) {
//     res.send({
//       'code': 200,
//       'msg': 'Get Success',
//       'data': result
//     })
//   } else {
//     res.send({
//       'code': 400,
//       'msg': 'non-existent'
//     })
//   }
// }




deleteBookId = async (req, res) => {
  let { id } = req.body;

  let result = await dbConfig.delete(dbConfig.BookInfo, { _id: id });

  if (result.deletedCount == 1) {
    res.send({
      'code': 200,
      'msg': 'Deleted successfully'
    })
  } else {
    res.send({
      'code': 400,
      'msg': 'Failed to delete'
    })
  }
}

addBook = async (req, res) => {
  let {
    name,
    author,
    press,
    press_time,
    price,
    isbn,
    desc
  } = req.body;

  let result = await dbConfig.insert(dbConfig.BookInfo, {
    name,
    author,
    press,
    press_time,
    price,
    ISBN: isbn,
    desc
  });

  if (result) {
    res.send({
      'code': 200,
      'msg': 'Add successfully'
    })
  } else {
    res.send({
      'code': 400,
      'msg': 'Add Failure'
    })
  }
}

module.exports = {
  getBookAll,
  findBook,
  findBookAuthor,
  findBookPrice,
  findBookIsbn,
  findBookId,
  deleteBookId,
  addBook
}