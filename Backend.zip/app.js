var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
var bookRouter = require('./routes/book');
var borrowRouter = require('./routes/borrow');

var bodyParser = require('body-parser')

var app = express();
var http = require('http');
var server = http.createServer(app);

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(express.json());
app.use(express.urlencoded({
  extended: false
}));
app.use(bodyParser.urlencoded({
  extended: true
}));

app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// Set up cross-domain requests
app.all('*', function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header('Access-Control-Allow-Headers', 'Content-Type, Content-Length, Authorization, Accept, X-Requested-With , yourHeaderField');
  res.header("Access-Control-Allow-Methods", "PUT,POST,GET,DELETE,OPTIONS");
  res.header("X-Powered-By", ' 3.2.1')
  res.header("Content-Type", "application/json;charset=utf-8");
  next();
});
// // Set cross-origin and response data format
app.all('/api/*', function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*')
  res.header('Access-Control-Allow-Headers', 'X-Requested-With, mytoken')
  res.header('Access-Control-Allow-Headers', 'X-Requested-With, Authorization')
  res.setHeader('Content-Type', 'application/json;charset=utf-8')
  res.header('Access-Control-Allow-Headers', 'Content-Type,Content-Length, Authorization, Accept,X-Requested-With')
  res.header('Access-Control-Allow-Methods', 'PUT,POST,GET,DELETE,OPTIONS')
  res.header('X-Powered-By', ' 3.2.1')
  if (req.method == 'OPTIONS') res.sendStatus(200)
  /* Let options requests return quickly */ else next()
})

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/book', bookRouter);
app.use('/borrow', borrowRouter);

server.listen('3000');
// Import socket.io and instantiate immediately, mounting server onto it
const io = require('socket.io')(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});
// Record all logged-in users
const userList = []
io.on('connection', socket =>{
  socket.on("login",data => {
    console.log(data);
    // Check, if data exists in userList array, it means the user is already logged in, login is not allowed
    // If data does not exist in userList array, it means the user is not logged in, login is allowed
    let user = userList.length !== 0 ? userList.find(item => item.username === data.username) : false
    if(user){
      // User exists, login failed, server needs to respond to the current user, indicating login failed
      socket.emit("userExit",{msg:"User already exists, login failed"})
    } else {
      // User does not exist, login successful
      userList.push(data)
      socket.emit("loginsuccess",{...data,msg:"Login successful"})
      // Tell all users that a user has joined the chat room, broadcast message: io.emit
      io.emit("addUser",data)
      // Tell all users how many people are in the chat room
      io.emit("userList",userList)
      // Store the successfully logged in username and avatar
      socket.username = data.username
    }
  })
  // User disconnect functionality
  socket.on("disconnect",()=>{
    // Remove the current user's information from userList
    let idx = userList.findIndex(item => item.username === socket.username)
    userList.splice(idx,1)
    // Tell everyone someone has left the chat room
    io.emit("leaveroom",{username:socket.username})
    // Tell everyone that userList has been updated
    io.emit("userList",userList)
  })
  // Listen for chat messages
  socket.on("sendMessage",data => {
    // Broadcast to all users
    io.emit("receiveMessage",data)
  })
  // Receive image information
  socket.on("sendImage",data => {
    // Broadcast to all users
    io.emit("receiveImage",data)
  })
});
