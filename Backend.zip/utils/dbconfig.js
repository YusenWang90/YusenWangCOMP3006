let mongoose = require("mongoose")
let url = "mongodb://127.0.0.1:27017/book"
mongoose
	.connect(url)
	.then((res) => {
		console.log("Link successful")
	})
	.catch((err) => {
		console.log(err)
	})
const bookInfoSchema = new mongoose.Schema({
  name: String,
  author: String,
  press: String,
  press_time: String,
  price: String,
  ISBN: String,
  desc: String
});
// const BookInfo = mongoose.model('BookInfo', bookInfoSchema);
const BookInfo = mongoose.models.BookInfo || mongoose.model('BookInfo', bookInfoSchema);
const userSchema = new mongoose.Schema({
  pwd: String,
  name: String,
  className: String,
  status: Number, // 0 is lost, 1 is normal.
  admin: Number, // 0 for normal users, 1 for administrators
  last_login_time: Date
});
const User = mongoose.models.User || mongoose.model('User', userSchema);

const borrowListSchema = new mongoose.Schema({
  book_id: { type: mongoose.Schema.Types.ObjectId, ref: 'BookInfo' },
  user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  borrow_date: Date,
  back_date: Date
});
const BorrowList = mongoose.models.BorrowList || mongoose.model('BorrowList', borrowListSchema);

// Import your models
// const BookInfo = require('./models/bookInfo');
// const User = require('./models/user');
// const BorrowList = require('./models/borrowList');

module.exports = {
  BookInfo,User,BorrowList,
  sqlConnect: function (model, query, callback) {
    console.log(model);
   return model.find(query, callback);
  },
  SySqlConnect: function (model, query) {
    console.log(query);
    return model.find(query).exec();
  },
  insert: function (model, doc) {
    return new model(doc).save();
  },
  update: function (model, conditions, doc) {
    return model.updateOne(conditions, doc);
  },
  delete: function (model, conditions) {
    return model.deleteOne(conditions);
  }
}