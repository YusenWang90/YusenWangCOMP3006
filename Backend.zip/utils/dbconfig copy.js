const mysql = require('mysql');

module.exports = {
  config: {
    host: '123.57.206.132',
    port: '3306',
    user: 'test1',
    password: 'GdKXAAdMptnPYyyS',
    database: 'test1'
  },
  sqlConnect: function (sql, sqlArr, callback) {
    var pool = mysql.createPool(this.config);
    pool.getConnection((err, conn) => {
      if (err) {
        console.log('---Database connection failure---')
        return;
      }

      conn.query(sql, sqlArr, callback);

      //release
      conn.release();
    })
  },
  SySqlConnect: function (sql, sqlArr) {
    return new Promise((resolve, reject) => {
      var pool = mysql.createPool(this.config);
      pool.getConnection((err, conn) => {
        if (err) {
          reject(err)
        } else {
          conn.query(sql, sqlArr, (err, data) => {
            if (err) {
              reject(err) //sql failure callback
            } else {
              resolve(data) //sql success callback
            }
          });
          //release
          conn.release();
        }
      })
    }).catch((err) => {
      console.log(err)
    })
  }
}
