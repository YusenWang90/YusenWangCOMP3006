<template>
  <div class="regist">
    <el-card class="box-card">
      <div class="login-title">Welcome to the Library Management System</div>
      <el-form
        :model="registForm"
        status-icon
        :rules="registRules"
        ref="registForm"
        size="medium"
      >
        <el-form-item prop="name">
          <el-input
            prefix-icon="el-icon-user-solid"
            type="text"
            v-model="registForm.name"
            autocomplete="off"
            placeholder="Please enter your name"
          ></el-input>
        </el-form-item>
        <el-form-item prop="pwd">
          <el-input
            prefix-icon="el-icon-s-cooperation"
            type="password"
            v-model="registForm.pwd"
            autocomplete="off"
            placeholder="Please enter your password"
          ></el-input>
        </el-form-item>
        <el-form-item prop="className">
          <el-input
            prefix-icon="el-icon-s-cooperation"
            type="text"
            v-model="registForm.className"
            autocomplete="off"
            placeholder="Please enter your class"
          ></el-input>
        </el-form-item>
        <el-form-item>
          <el-radio v-model="registForm.admin" label="0">Student</el-radio>
          <el-radio v-model="registForm.admin" label="1">Adminr</el-radio>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitForm">Register Now</el-button>
          <el-button @click="resetForm">Already have an account, go log in</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import { getRegist, getLogin } from "@/request";
export default {
  data() {
    return {
      registForm: { name: "", pwd: "", className: "", admin: "0" },
      registRules: {
        name: [
          { required: true, message: "Please enter your name", trigger: "blur" },
          { min: 2, max: 5, message: "Name length between 2 and 5！", trigger: "blur" },
        ],
        pwd: [
          { required: true, message: "Please enter your password", trigger: "blur" },
          { min: 3, max: 12, message: "Password length between 3 and 12！", trigger: "blur" },
        ],
        className: [
          { required: true, message: "Please enter your class", trigger: "blur" },
          { min: 3, max: 15, message: "Please enter a valid class！", trigger: "blur" },
        ],
      },
    };
  },
  methods: {
    resetForm() {
      this.$router.push("/login");
    },
    submitForm() {
      this.$refs.registForm.validate(async (valid) => {
        if (!valid) return this.$message.error("Please complete the valid registration information！");
        const data = await getRegist(this.registForm);
        if (data.code != 200) return this.$message.error(data.msg);

        this.$message.success(data.msg);
        this.login();
      });
    },
    async login() {
      const data = await getLogin({
        name: this.registForm.name,
        pwd: this.registForm.pwd,
      });
      if (data.code != 200) {
        this.$message.error(data.msg);
        return;
      }

      window.sessionStorage.setItem("user", JSON.stringify(data.data));
      this.$message.success(data.msg);
      this.$router.push("/home");
    },
  },
};
</script>

<style lang="scss" scoped>
.regist {
  position: relative;
  height: 100%;
  color: $font-color;
  background-color: rgba($color: #000000, $alpha: 0.4);

  &::after {
    content: "";
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    background-image: url("../assets/imgs/1111.jpg");
    background-repeat: no-repeat;
    background-size: 100% 100%;
    background-attachment: fixed;
    filter: blur(3px);
    // z-index: -100;
  }

  .box-card {
    z-index: 200;
    position: absolute;
    top: 25%;
    left: 50%;
    transform: translate(-50%);
    min-width: 500px;
    padding: 30px;
  }
  .login-title {
    font-size: 20px;
    margin-bottom: 50px;
  }
}
</style>
