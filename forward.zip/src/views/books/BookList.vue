<template>
  <div>
    <el-breadcrumb class="breadcrumb-row" separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/' }">Home</el-breadcrumb-item>
      <el-breadcrumb-item>Book Management</el-breadcrumb-item>
      <el-breadcrumb-item>Book Information Query</el-breadcrumb-item>
    </el-breadcrumb>

    <el-card>
      <el-row>
        <el-col :span="12">
          <el-input placeholder="Please enter content" v-model="bookParams.bookname">
            <el-select v-model="selectType" slot="prepend" placeholder="Please select">
              <el-option label="Book Name" value="1"></el-option>
              <el-option label="Author" value="2"></el-option>
              <el-option label="ISBN Number" value="3"></el-option>
              <el-option label="Book ID" value="4"></el-option>
            </el-select>
            <el-button slot="append" icon="el-icon-search" @click="searchClick"></el-button>
          </el-input>
        </el-col>
        <el-col :span="12">
          <div class="grid-content bg-purple-light"></div>
        </el-col>
      </el-row>

      <!-- Table Section -->
      <el-table :data="bookList" style="width: 100%" size="medium">
        <el-table-column type="expand">
          <template slot-scope="props">
            <el-form label-position="left" class="style-table-expand" label-width="100px">
              <el-form-item label="Book ID:">
                <span>{{ props.row._id }}</span>
              </el-form-item>
              <el-form-item label="Book Name:">
                <span>{{ props.row.name }}</span>
              </el-form-item>
              <el-form-item label="Publisher:">
                <span>{{ props.row.press }}</span>
              </el-form-item>
              <el-form-item label="Publication Time:">
                <span>{{ props.row.press_time }}</span>
              </el-form-item>
              <el-form-item label="Book Price:">
                <span>{{ props.row.price }}</span>
              </el-form-item>
              <el-form-item label="Book Description:">
                <span>{{ props.row.desc }}</span>
              </el-form-item>
            </el-form>
          </template>
        </el-table-column>
        <el-table-column type="index" label="#"></el-table-column>
        <el-table-column label="Book ISBN" prop="ISBN" sortable></el-table-column>
        <el-table-column label="Book Name" prop="name" sortable></el-table-column>
        <el-table-column label="Book Author" prop="author" sortable></el-table-column>
        <el-table-column label="Book Photo">
          <template>
            <img src="../../assets/imgs/book.jpg" alt class="img-wrap" />
          </template>
        </el-table-column>
        <el-table-column label="Actions">
          <template slot-scope="objscope">
            <el-tooltip content="Edit Book" placement="top-start">
              <el-button
                type="primary"
                icon="el-icon-edit"
                size="small"
                @click="editBookClick(objscope.row)"
              ></el-button>
            </el-tooltip>
            <el-tooltip content="Delete Book" placement="top-start">
              <el-button
                type="danger"
                icon="el-icon-delete"
                size="small"
                @click="deleteBookClick(objscope.row)"
              ></el-button>
            </el-tooltip>
          </template>
        </el-table-column>
      </el-table>

      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="bookParams.pagenum"
        :page-sizes="[5, 10, 15, 20]"
        :page-size="bookParams.pagesize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
        prev-text="Previous"
        next-text="Next"
        first-text="First"
        last-text="Last"
      >
  <template v-slot:page-size="{ value }">
    {{ value }} items per page
  </template>
</el-pagination>

    </el-card>
  </div>
</template>

<script>
import {
  findBook,
  findBookAuthor,
  findBookIsbn,
  findBookId,
  deleteBookId
} from "@/request";
export default {
  data() {
    return {
      selectType: "1",
      valueSearch: "",
      bookParams: {
        bookname: "", // Name
        pagenum: 1, // Current page number
        pagesize: 5
      },
      total: 0,
      bookList: []
    };
  },
  created() {
    this.getBookList();
  },
  methods: {
    searchClick() {
      this.getBookData();
    },
    async getBookData() {
      if (this.selectType == 1) {
        this.getBookList();
      } else {
        let data;
        if (this.selectType == 2) {
          data = await findBookAuthor({
            author: this.bookParams.bookname
          });
        } else if (this.selectType == 3) {
          data = await findBookIsbn({
            isbn: this.bookParams.bookname
          });
        } else if (this.selectType == 4) {
          data = await findBookId({
            id: this.bookParams.bookname
          });
        }
        if (data.code != 200) return this.$message.error(data.msg);
        this.$message.success(data.msg);
        this.total = data.data.length;
        this.bookList = data.data;
      }
    },
    async getBookList() {
      const data = await findBook(this.bookParams);
      if (data.code != 200) return this.$message.error(data.msg);

      this.$message.success(data.msg);
      this.total = data.data.total;
      this.bookList = data.data.result;
    },
    handleSizeChange(num) {
      this.bookParams.pagesize = num;
      this.getBookList();
    },
    handleCurrentChange(curnum) {
      this.bookParams.pagenum = curnum;
      this.getBookList();
    },
    deleteBookClick(obj) {
      this.$confirm("Are you sure you want to delete the book 【" + obj.name + "】?", "Prompt", {
        confirmButtonText: "Confirm",
        cancelButtonText: "Cancel",
        type: "warning"
      })
        .then(async () => {
          const data = await deleteBookId({ id: obj._id });
          if (data.code != 200) return this.$message.error(data.msg);
          this.$message({
            type: "success",
            message: "Deleted successfully!"
          });
          this.getBookList();
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "Deletion cancelled"
          });
        });
    },
    editBookClick(obj) {
      this.$notify({
        title: "Warning",
        message: "The book editing function is not supported yet~",
        type: "warning"
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.style-table-expand {
  font-size: 0;
  color: #99a9bf;
  .el-form-item {
    margin-right: 0;
    margin-bottom: 0;
    width: 50%;

    label {
      width: 90px;
    }
    span {
    }
  }
}
.img-wrap {
  max-width: 70px;
}
</style>
