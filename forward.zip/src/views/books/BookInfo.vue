<template>
  <div>
    <el-breadcrumb class="breadcrumb-row" separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/' }">Home</el-breadcrumb-item>
      <el-breadcrumb-item>Book Management</el-breadcrumb-item>
      <el-breadcrumb-item>Book Information Addition</el-breadcrumb-item>
    </el-breadcrumb>

    <el-card>
      <el-steps :active="Number(activeTab)" simple>
        <el-step title="Complete Information" icon="el-icon-s-order"></el-step>
        <el-step title="Complete Author" icon="el-icon-s-custom"></el-step>
        <el-step title="Complete Publicatio" icon="el-icon-upload"></el-step>
        <el-step title="Complete Description" icon="el-icon-picture"></el-step>
      </el-steps>
      <el-row :gutter="20" class="content-row">
        <el-col :span="16">
          <el-form :model="addForm" :rules="addrules" ref="addbookForm">
            <el-tabs tab-position="left" v-model="activeTab" :before-leave="beforeLeave">
              <el-tab-pane label="Book Information" name="1">
                <el-form-item label="Book ISBN" prop="isbn">
                  <el-input v-model="addForm.isbn"></el-input>
                </el-form-item>
                <el-form-item label="Book Name" prop="name">
                  <el-input v-model="addForm.name"></el-input>
                </el-form-item>
                <el-form-item label="Book Price" prop="price">
                  <el-input v-model="addForm.price"></el-input>
                </el-form-item>
              </el-tab-pane>
              <el-tab-pane label="Book Author" name="2">
                <el-form-item label="Author Name" prop="author">
                  <el-input v-model="addForm.author"></el-input>
                </el-form-item>
              </el-tab-pane>
              <el-tab-pane label="Book Publication" name="3">
                <el-form-item label="Publisher" prop="press">
                  <el-input v-model="addForm.press"></el-input>
                </el-form-item>
                <el-form-item label="出Publication Time" prop="press_time">
                  <el-date-picker
                    format="yyyy-MM-dd"
                    value-format="yyyy-MM"
                    v-model="addForm.press_time"
                    type="date"
                    placeholder="Select Date"
                  ></el-date-picker>
                </el-form-item>
              </el-tab-pane>
              <el-tab-pane label="Book Description" name="4">
                <el-form-item label="Brief Description of the Book" prop="desc">
                  <el-input
                    type="textarea"
                    placeholder="Please enter a brief description of the book..."
                    v-model="addForm.desc"
                    maxlength="30"
                    show-word-limit
                    rows="12"
                  ></el-input>
                </el-form-item>
                <el-button type="primary" @click="addBookClick">Add Book</el-button>
              </el-tab-pane>
            </el-tabs>
          </el-form>
        </el-col>
        <el-col :span="8">
          <img src="../../assets/imgs/book.jpg" alt />
        </el-col>
      </el-row>
    </el-card>
  </div>
</template>

<script>
import { addBook } from "@/request";
export default {
  data() {
    return {
      addForm: {
        name: "",
        author: "",
        press: "",
        press_time: "",
        price: "",
        isbn: "",
        desc: ""
      },
      addrules: {
        name: [
          { required: true, message: "Book name cannot be empty", trigger: "blur" }
        ],
        author: [
          { required: true, message: "Author name cannot be empty", trigger: "blur" }
        ],
        press: [{ required: true, message: "Publisher cannot be empty", trigger: "blur" }],
        press_time: [
          { required: true, message: "Publication time cannot be empty", trigger: "blur" }
        ],
        price: [
          { required: true, message: "Book price cannot be empty", trigger: "blur" },
          {
            type: "number",
            message: "Must be a number",
            trigger: "blur",
            transform: value => Number(value)
          }
        ],
        isbn: [{ required: true, message: "ISBN cannot be empty", trigger: "blur" }],
        desc: [{ required: true, message: "Book description cannot be empty", trigger: "blur" }]
      },
      activeTab: "1"
    };
  },
  methods: {
    beforeLeave(activeName, oldActiveName) {
      if (oldActiveName == 1) {
        if (!this.addForm.name || !this.addForm.isbn || !this.addForm.price) {
          this.$message.error("Please improve the information of the book");
          return false;
        }
        return true;
      }
      return true;
    },
    addBookClick() {
      this.$refs.addbookForm.validate(async valid => {
        if (!valid) return this.$message.error("Please improve the content of the book form");
        const data = await addBook(this.addForm);
        if (data.code != 200) return this.$message.error(data.msg);

        this.$message.success(data.msg);

        this.activeTab = "1";
        this.$refs.addbookForm.resetFields();
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.content-row {
  margin-top: 50px;
}
.el-tab-pane {
  text-align: left;
}
</style>
