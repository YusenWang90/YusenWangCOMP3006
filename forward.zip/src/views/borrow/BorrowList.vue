<!--
 * @Author: Wang Yusen
 * @Date: 2024-01-02 16:36:50
 * @LastEditors: Wang Yusen
 * @LastEditTime: 2024-01-04 09:07:38
 * @FilePath: \book_admin-master\src\views\borrow\BorrowList.vue
 * @Description: This is the default setting, please set `customMade`, Open koroFileHeader to view and set the configuration: https://github.com/OBKoro1/koro1FileHeader/wiki/Configuration
-->
<template>
  <div>
    <el-breadcrumb class="breadcrumb-row" separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/' }">Home</el-breadcrumb-item>
      <el-breadcrumb-item>Borrowing Management</el-breadcrumb-item>
      <el-breadcrumb-item>Book Borrowing Records</el-breadcrumb-item>
    </el-breadcrumb>

    <el-card>
      <el-table :data="borrowList" stripe style="width: 100%">
        <el-table-column type="index" label="#"></el-table-column>
        <el-table-column prop="book_id._id" label="Book ID"></el-table-column>
        <el-table-column prop="book_id.name" label="Book Name"></el-table-column>
        <el-table-column prop="book_id.press" label="Publisher"></el-table-column>
        <el-table-column prop="book_id.author" label="Author"></el-table-column>
        <el-table-column prop="user_id.name" label="Borrower"></el-table-column>
        <el-table-column prop="user_id._id" label="Borrower ID"></el-table-column>
        <el-table-column prop="borrow_date" label="Borrow Date" sortable width="200px"></el-table-column>
        <el-table-column prop="back_date" label="Return Date" sortable width="200px"></el-table-column>
        <el-table-column
          label="Returned"
          :filters="[{ text: 'Returned', value: '1' }, { text: 'Not Returned', value: '0' }]"
          :filter-method="filterMethod"
          filter-placement="bottom-end"
        >
          <template slot-scope="scope">
            <el-tag
              :type="scope.row.back_date ? 'primary' : 'success'"
              disable-transitions
            >{{ scope.row.back_date ? 'Returned' : 'Not Returned' }}</el-tag>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script>
import { getBorrowAll } from "@/request";
export default {
  data() {
    return {
      borrowList: []
    };
  },
  created() {
    this.getBorrowList();
  },
  methods: {
    async getBorrowList() {
      const data = await getBorrowAll();
      if (data.code != 200) return this.$message.error(data.msg);
      this.borrowList = data.data;
    },
    filterMethod(value, row) {
      if (value == 1) {
        return row.back_date;
      } else {
        return !row.back_date;
      }
    }
  }
};
</script>

<style>
</style>
