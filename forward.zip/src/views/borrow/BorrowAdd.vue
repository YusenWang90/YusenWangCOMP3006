<template>
  <div>
    <el-breadcrumb class="breadcrumb-row" separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/' }">Home</el-breadcrumb-item>
      <el-breadcrumb-item>Borrowing Management</el-breadcrumb-item>
      <el-breadcrumb-item>Add Borrowing</el-breadcrumb-item>
    </el-breadcrumb>

    <el-card>
      <el-tabs type="border-card">
        <!-- Borrowing Addition -->
        <el-tab-pane>
          <span slot="label">
            <i class="el-icon-date"></i> Add Borrowing
          </span>
          <el-row>
            <el-col :span="15">
              <el-form label-width="100px" :model="formBook" ref="bookAddFrom" class="bookAddFrom">
                <el-form-item label="Book ID">
                  <el-input v-model="formBook.book_id" @change="idChangeEvent"></el-input>
                </el-form-item>
                <el-form-item label="Book Name">
                  <el-input v-model="formBook.book_name" @change="bookNameChangeEvent"></el-input>
                </el-form-item>
                <el-form-item label="Book Author">
                  <el-input v-model="formBook.author" disabled></el-input>
                </el-form-item>
                <el-form-item label="Publisher">
                  <el-input v-model="formBook.press" disabled></el-input>
                </el-form-item>
                <el-form-item label="Borrower ID">
                  <el-input v-model="formBook.user_id" disabled></el-input>
                </el-form-item>
                <el-form-item label="Borrower">
                  <el-input v-model="formBook.user_name" @change="userChangeEvent"></el-input>
                </el-form-item>
                <el-form-item label="Number of Copies Borrowed">
                  <el-input value="1" type="Number" disabled></el-input>
                </el-form-item>
                <el-form-item label="Borrowing Time">
                  <el-input type="text" suffix-icon="el-icon-date" :value="new Date()+''" disabled></el-input>
                </el-form-item>
              </el-form>
              <el-button type="primary" @click="addBorrowClick">Proceed with Borrowing</el-button>
              <el-button type="info" @click="resetClick">Reset</el-button>
            </el-col>
            <el-col :span="9">
              <img src="../../assets/imgs/book.jpg" alt />
            </el-col>
          </el-row>
        </el-tab-pane>
        <!-- Returning Addition -->
        <el-tab-pane label="Returning">
          <el-form :inline="true" :model="addreturnFrom">
            <el-form-item label="Borrower">
              <el-input
                v-model="addreturnFrom.username"
                @change="addreturnnameChangeEvent"
                placeholder="Borrower's Name"
              ></el-input>
            </el-form-item>
            <el-form-item label="Borrowed Book">
              <el-select v-model="addreturnFrom.book_id" placeholder="Borrowed Book List">
                <el-option
                  :label="item.book_id.name"
                  :value="item.book_id._id"
                  v-for="(item,index) in selectList"
                  :key="index"
                ></el-option>
              </el-select>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="submitClick">Return Book</el-button>
            </el-form-item>
          </el-form>
        </el-tab-pane>
      </el-tabs>
    </el-card>
  </div>
</template>


<script>
import {
  findBookId,
  findUserInfo,
  findBook,
  findBorrowUser,
  addBookStatus,
  addBorrow
} from "@/request";
export default {
  data() {
    return {
      formBook: {
        book_id: "",
        book_name: "",
        author: "",
        press: "",
        user_id: "",
        user_name: ""
      },
      addreturnFrom: {
        username: "",
        book_id: "",
        user_id: ""
      },
      selectList: []
    };
  },
  methods: {
    resetClick() {
      this.$refs.bookAddFrom.resetFields();
    },
    async idChangeEvent(value) {
      let data = await findBookId({ id: value });
      if (data.code != 200) {
        this.formBook = {};
        this.$message.error("The book does not exist, please re-enter the correct book ID!");
        return;
      }
      this.formBook.book_name = data.data.name;
      this.formBook.author = data.data.author;
      this.formBook.press = data.data.press;
    },
    async bookNameChangeEvent(value) {
      let data = await findBook({ bookname: value });
      if (data.code != 200) {
        this.formBook.user_id = "";
        this.formBook.user_name = "";
        this.formBook.author = "";
        this.formBook.press = "";
        this.$message.error("The book does not exist, please re-enter the correct book name!");
        return;
      }
      this.formBook.book_id = data.data.result[0]._id;
      this.formBook.book_name = data.data.result[0].name;
      this.formBook.author = data.data.result[0].author;
      this.formBook.press = data.data.result[0].press;
    },
    async userChangeEvent(value) {
      let data = await findUserInfo({ name: value });
      if (data.code != 200) {
        this.formBook.user_id = "";
        this.formBook.user_name = "";
        this.$message.error("The user does not exist, please re-enter the correct user name!");
        return;
      }
      this.formBook.user_id = data.data._id;
    },
    async addreturnnameChangeEvent(value) {
      let data = await findUserInfo({ name: value });
      if (data.code != 200) {
        this.selectList = [];
        this.$message.error("The user does not exist, please re-enter the correct user name!");
        return;
      }

      let result = await findBorrowUser({ user_id: data.data._id });
      this.addreturnFrom.user_id = data.data._id;
      if (result.code != 200) {
        this.selectList = [];
        this.$message.error("This user does not have any books to return!");
        return;
      }
      this.selectList = result.data;
    },
    async submitClick() {
      let data = await addBookStatus({
        user_id: this.addreturnFrom.user_id,
        book_id: this.addreturnFrom.book_id
      });
      if (data.code != 200) return this.$message.error("Failed to return the book");
      this.$message.success("Book returned successfully");
      this.addreturnFrom = {};
    },
    async addBorrowClick() {
      if (!this.formBook.book_id || !this.formBook.user_id)
        return this.$message.error("Please enter valid borrowing information");
      let data = await addBorrow({
        book_id: this.formBook.book_id,
        user_id: this.formBook.user_id
      });
      if (data.code != 200) return this.$message.error("Borrowing failed");
      this.$message.success("Borrowing successful");
      this.$refs.bookAddFrom.resetFields();
    }
  }
};
</script>

<style lang="scss" scoped>
.formValue {
  color: darkblue;
}
</style>

