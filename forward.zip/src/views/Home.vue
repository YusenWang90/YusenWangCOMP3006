<template>
  <div class="home home-page">
    <el-container class="home-row">
      <el-header>
        <div class="header-title">
          <h4>Book Management System</h4>
        </div>
        <div>
          <el-button
            type="primary"
            @click="openChat"
            icon="el-icon-chat-dot-round"
            circle
          ></el-button>

          <el-button type="info" @click="exitClick">Exit</el-button>
        </div>
      </el-header>
      <el-container>
        <!-- Sidebar Section -->
        <el-aside :width="isCollapse ? '65px' : '200px'">
          <div class="flex-bott" @click="collapseClick">
            <i class="el-icon-more-outline" v-if="isCollapse"></i>
            <i v-else class="el-icon-more"></i>
          </div>
          <el-menu
            :default-active="activeMenuId"
            unique-opened
            router
            class="el-menu-vertical-demo"
            background-color="#363D40"
            text-color="#fff"
            active-text-color="#ffd04b"
            :collapse="isCollapse"
            :collapse-transition="false"
          >
            <el-submenu
              :index="item.id + ''"
              v-for="item in menulist"
              :key="item.id"
            >
              <template slot="title">
                <i :class="'iconfont ' + item.icon"></i>
                <span slot="title">{{ item.authName }}</span>
              </template>
              <el-menu-item
                :index="'/' + item2.path"
                v-for="item2 in item.children"
                :key="item2.id"
              >
                <i class="iconfont el-icon-menu"></i>
                {{ item2.authName }}
              </el-menu-item>
            </el-submenu>
          </el-menu>
        </el-aside>

        <!-- Main Content Section -->
        <el-main>
          <router-view></router-view>
        </el-main>
      </el-container>
    </el-container>
    <chat ref="chat" v-if="chatShow" />

  </div>
</template>

<script>
import menulist from "../assets/list.json";
import chat from "./chat/Login.vue";
export default {
  name: "Home",
  components: { chat },
  data() {
    return {
      chatShow:false,
      isCollapse: false,
      chatVisible: false,
      menulist: menulist.menulist,
    };
  },
  computed: {
    activeMenuId: {
      get() {
        return this.$route.path;
      },
      set(val) {},
    },
  },
  methods: {
    collapseClick() {
      this.isCollapse = !this.isCollapse;
      console.log(this.menulist);
    },
    openChat() {
      this.chatShow=true
      this.$nextTick(()=>{

        this.$refs.chat.show();
      })
    },
    exitClick() {
  this.$confirm("Are you sure you want to exit your account? Do you wish to continue?", "Prompt", {
    confirmButtonText: "Confirm",
    cancelButtonText: "Cancel",
    type: "warning",
  })
    .then(() => {
      window.sessionStorage.clear();
      this.$router.push("/login");
      this.$message({
        type: "success",
        message: "Successfully exited!",
      });
    })
    .catch(() => {
      this.$message({
        type: "info",
        message: "Exit cancelled!",
      });
    });
},

  },
};
</script>

<style lang="scss" scoped>
.home {
  height: 100%;
}
.home-row {
  height: 100vh;
}
.el-header {
  background-color: $page-color-header;
  height: 70px !important;
  display: flex;
  align-items: center;
  justify-content: space-between;
  box-sizing: border-box;
  .header-title {
    display: flex;
    font-size: 20px;
    height: 100%;
    img {
      height: 100%;
      margin-right: 5px;
    }
    h4 {
      color: white;
      font-family: Georgia, "Times New Roman", Times, serif;
    }
  }
}
.el-aside {
  background-color: $page-color-aside;
  .flex-bott {
    color: white;
    padding: 10px 0 20px 0;
  }
  .el-menu {
    border: none;
    .el-submenu {
      text-align: left;
      .iconfont {
        margin-right: 10px;
      }
    }
  }
}
.el-main {
}
</style>
