<template>
  <div>
    <el-breadcrumb class="breadcrumb-row" separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/' }">Home</el-breadcrumb-item>
      <el-breadcrumb-item>User Management</el-breadcrumb-item>
      <el-breadcrumb-item>User Profile</el-breadcrumb-item>
    </el-breadcrumb>
    <el-card>
      <div class="content-row">
        <h2>Your Current Information</h2>
        <el-form label-position="left" label-width="80px" :model="userinfo" size="medium">
          <el-form-item label="ID">
            <el-input v-model="userinfo._id" disabled></el-input>
          </el-form-item>
          <el-form-item label="Name">
            <el-input v-model="userinfo.name" disabled></el-input>
          </el-form-item>
          <el-form-item label="Class">
            <el-input v-model="userinfo.className" disabled></el-input>
          </el-form-item>
          <el-form-item label="Status">
            <el-input :value="userinfo.status==1?'In Use':'Lost'" disabled></el-input>
          </el-form-item>
          <el-form-item label="Role">
            <el-input :value="userinfo.admin==0?'Student':'Administrator'" disabled></el-input>
          </el-form-item>
          <el-form-item label="Registration Time">
            <el-input v-model="userinfo.last_login_time" disabled></el-input>
          </el-form-item>
          <el-form-item label="Password" class="pass-line-row">
            <el-button type="primary" @click="showUpdalog">Change Password</el-button>
          </el-form-item>
        </el-form>

        <!-- Change Password -->
        <el-dialog title="Change Password" :visible.sync="dialogFormVisible" width="500px">
          <el-form :model="editParams" label-width="120px" :rules="formrules" ref="editForm">
            <el-form-item label="Old Password" prop="orlpass">
              <el-input v-model="editParams.orlpass" type="password" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="New Password" prop="newpass">
              <el-input v-model="editParams.newpass" type="password"></el-input>
            </el-form-item>
            <el-form-item label="Confirm New Password" prop="yespass">
              <el-input v-model="editParams.yespass" type="password"></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible = false">Cancel</el-button>
            <el-button type="primary" @click="upPassClick">Confirm</el-button>
          </div>
        </el-dialog>
      </div>
    </el-card>
  </div>
</template>


<script>
import { findUserInfo, editUserpass } from "@/request";

export default {
  data() {
    var validatorPass = (rule, value, callback) => {
      if (value !== this.editParams.newpass) {
        callback(new Error("The two passwords do not match"));
        return;
      }
      callback();
    };
    return {
      editParams: { orlpass: "", newpass: "", yespass: "" },
      formrules: {
        orlpass: [{ required: true, message: "Please enter the password", trigger: "blur" }],
        newpass: [
          { required: true, message: "Please enter the password", trigger: "blur" },
          {
            min: 3,
            max: 12,
            message: "Password length must be between 3-12 characters",
            trigger: "blur"
          }
        ],
        yespass: [
          { required: true, message: "Please enter the password", trigger: "blur" },
          {
            min: 3,
            max: 12,
            message: "Password length must be between 3-12 characters",
            trigger: "blur"
          },
          {
            validator: validatorPass,
            trigger: "blur"
          }
        ]
      },
      userinfo: {},
      dialogFormVisible: false,
      upForm: {}
    };
  },
  created() {
    this.findUserinfo();
  },
  methods: {
    async findUserinfo() {
      const user = JSON.parse(window.sessionStorage.getItem("user"));
      // const data = await findUserInfo({ name: user.name });
      // console.log(user);
      this.userinfo = user ? user : {};
    },
    showUpdalog() {
      this.dialogFormVisible = true;
    },
    async upPassClick() {
      this.$refs.editForm.validate(async valid => {
        if (!valid) return this.$message.error("Please complete the modification information!");
        const data = await editUserpass({
          id: this.userinfo._id,
          pwd: this.editParams.orlpass,
          newpwd: this.editParams.yespass
        });
        if (data.code != 200) return this.$message.error(data.msg);

        this.$message.success(data.msg);
        this.dialogFormVisible = false;
        this.$refs.editForm.resetFields();

        window.sessionStorage.clear();
        this.$router.push("/login");
      });
    }
  }
};
</script>


<style lang="scss" scoped>
.content-row {
  margin: 0 auto;
  max-width: 600px;
}
.pass-line-row {
  text-align: left;
}
</style>
