<template>
  <div>
    <el-breadcrumb class="breadcrumb-row" separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/' }">Home</el-breadcrumb-item>
      <el-breadcrumb-item>User Management</el-breadcrumb-item>
      <el-breadcrumb-item>User List</el-breadcrumb-item>
    </el-breadcrumb>

    <el-card>
      <!-- Header -->
      <el-row class="card-head-row">
        <el-col :span="8">
          <div class="grid-content bg-purple-dark"></div>
          <el-input placeholder="Please enter the name to search" v-model="searchName">
            <el-button slot="append" icon="el-icon-search" @click="findUserClick"></el-button>
          </el-input>
        </el-col>
        <el-col :span="3">
          <el-button type="primary" @click="showAddUserDialog">Add User</el-button>
        </el-col>
      </el-row>
      <!-- Table -->
      <el-table :data="userData" stripe border>
        <el-table-column type="index"></el-table-column>
        <el-table-column prop="_id" label="ID"></el-table-column>
        <el-table-column prop="name" label="Name"></el-table-column>
        <el-table-column prop="className" label="Class"></el-table-column>
        <el-table-column label="Status">
          <template slot-scope="statusscope">
            <el-switch
              :value="statusscope.row.status?true:false"
              active-color="#13ce66"
              inactive-color="#ff4949"
              @change="switchChange(statusscope.row)"
            ></el-switch>
          </template>
        </el-table-column>
        <el-table-column prop="admin" label="Role">
          <template slot-scope="adminscope">
            <el-tag v-if="adminscope.row.admin">Administrator</el-tag>
            <el-tag v-else type="info">Student</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="last_login_time" label="Registration Time" min-width="150px"></el-table-column>
        <el-table-column label="Actions">
          <template slot-scope="deleUser">
            <el-tooltip content="Edit User" placement="top-start">
              <el-button
                type="primary"
                icon="el-icon-edit"
                size="mini"
                circle
                @click="editUser(deleUser.row)"
              ></el-button>
            </el-tooltip>
            <el-tooltip content="Delete User" placement="top-start">
              <el-button
                type="danger"
                icon="el-icon-delete"
                size="mini"
                circle
                @click="deleteUser(deleUser.row)"
              ></el-button>
            </el-tooltip>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

<!-- Add User Dialog -->
<el-dialog title="Add User" :visible.sync="dialogAddVisible" width="500px">
  <el-form :model="addForm" status-icon :rules="addRules" ref="adduserForm" size="medium">
    <el-form-item prop="name">
      <el-input
        prefix-icon="el-icon-user-solid"
        type="text"
        v-model="addForm.name"
        autocomplete="off"
        placeholder="Please enter the name"
      ></el-input>
    </el-form-item>
    <el-form-item prop="pwd">
      <el-input
        prefix-icon="el-icon-s-cooperation"
        type="password"
        v-model="addForm.pwd"
        autocomplete="off"
        placeholder="Please enter the password"
      ></el-input>
    </el-form-item>
    <el-form-item prop="className">
      <el-input
        prefix-icon="el-icon-s-cooperation"
        type="text"
        v-model="addForm.className"
        autocomplete="off"
        placeholder="Please enter the class"
      ></el-input>
    </el-form-item>
    <el-form-item>
      <el-radio v-model="addForm.admin" label="0">Student</el-radio>
      <el-radio v-model="addForm.admin" label="1">Administrator</el-radio>
    </el-form-item>
  </el-form>
  <div slot="footer" class="dialog-footer">
    <el-button @click="dialogAddVisible = false">Cancel</el-button>
    <el-button type="primary" @click="addUserClick">Confirm</el-button>
  </div>
</el-dialog>


<!-- Edit User Information -->
<el-dialog title="Edit User Information" :visible.sync="dialogUpVisible" width="500px">
  <el-form :model="upForm" status-icon :rules="addRules" ref="upuserForm" size="medium">
    <el-form-item prop="name">
      <el-input
        prefix-icon="el-icon-user-solid"
        type="text"
        v-model="upForm.name"
        autocomplete="off"
        placeholder="Please enter the name"
      ></el-input>
    </el-form-item>
    <el-form-item prop="className">
      <el-input
        prefix-icon="el-icon-s-cooperation"
        type="text"
        v-model="upForm.className"
        autocomplete="off"
        placeholder="Please enter the class"
      ></el-input>
    </el-form-item>
    <el-form-item>
      <el-radio v-model="upForm.admin" label="0">Student</el-radio>
      <el-radio v-model="upForm.admin" label="1">Administrator</el-radio>
    </el-form-item>
  </el-form>
  <div slot="footer" class="dialog-footer">
    <el-button @click="dialogUpVisible = false">Cancel</el-button>
    <el-button type="primary" @click="upUserClick">Confirm</el-button>
  </div>
</el-dialog>
</div>
</template>


<script>
import {
  getUserAll,
  updateUserstat,
  findUsername,
  getRegist,
  deletUser,
  upUserinfo
} from "@/request";
export default {
  data() {
    return {
      dialogAddVisible: false,
      dialogUpVisible: false,
      userData: [],
      searchName: "",
      addForm: { name: "", pwd: "", className: "", admin: "0" },
      upForm: {},
      addRules: {
        name: [
          { required: true, message: "Please enter the name", trigger: "blur" },
          { min: 3, max: 5, message: "The length of the name should be between 2~5 characters!", trigger: "blur" }
        ],
        pwd: [
          { required: true, message: "Please enter the password", trigger: "blur" },
          { min: 3, max: 12, message: "Password length should be between 3~12 characters!", trigger: "blur" }
        ],
        className: [
          { required: true, message: "Please enter the class", trigger: "blur" },
          { min: 3, max: 15, message: "Please enter a valid class!", trigger: "blur" }
        ]
      }
    };
  },
  created() {
    this.getUserlist();
  },
  computed: {},
  methods: {
    async getUserlist() {
      const data = await getUserAll();
      if (data.code != 200) return this.$message.error(data.msg);

      this.userData = data.data;
    },
    async switchChange(obj) {
      console.log(obj, obj.status);
      obj.status = obj.status ? 0 : 1;
      const data = await updateUserstat({ id: obj._id, status: obj.status });
      if (data.code != 200) return this.$message.error(data.msg);
      console.log(data);
      this.$message.success(data.msg);
      this.getUserlist();
    },
    async findUserClick() {
      const data = await findUsername({ name: this.searchName });
      if (data.code != 200) return this.$message.error(data.msg);
      this.userData = data.data;
    },
    showAddUserDialog() {
      this.dialogAddVisible = true;
    },
    addUserClick() {
      this.$refs.adduserForm.validate(async valid => {
        if (!valid) return this.$message.error("Please complete the registration information!");
        const data = await getRegist(this.addForm);
        if (data.code != 200) return this.$message.error(data.msg);

        this.$message.success(data.msg);
        this.$refs.adduserForm.resetFields();
        this.dialogAddVisible = false;
        this.getUserlist();
      });
    },
    deleteUser(obj) {
      this.$confirm("Are you sure you want to delete the user: " + obj.name + "?", "Prompt", {
        confirmButtonText: "Confirm",
        cancelButtonText: "Cancel",
        type: "warning"
      })
        .then(async () => {
          const data = await deletUser({ id: obj._id });
          if (data.code != 200) return this.$message.error(data.msg);
          this.$message({
            type: "success",
            message: "Successfully deleted!"
          });
          this.getUserlist();
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "Deletion cancelled"
          });
        });
    },
    editUser(obj) {
      this.upForm = {
        id: obj._id,
        name: obj.name,
        className: obj.className,
        admin: obj.admin + ""
      };
      this.dialogUpVisible = true;
    },
    async upUserClick() {
      this.$refs.upuserForm.validate(async valid => {
        if (!valid) return this.$message.error("Please complete the registration information!");
        const data = await upUserinfo(this.upForm);
        if (data.code != 200) this.$message.error(data.msg);
        this.$message.success(data.msg);
        this.dialogUpVisible = false;
        this.$refs.upuserForm.resetFields();
        this.getUserlist();
      });
    }
  }
};
</script>

<style>
</style>
